mathsApp.controller('PageController',
    function($scope, author) {

        $scope.author = author;
        $scope.year = '2020';
    });